#!usr/bin/env python

#INFO
__author__ = "Alana Ackermans"
__version__ = "0.0.1"

#LIBRARIES

#LISTS
cijfers = []

#FUNCTIONS
def data_toevoegen(randomgetal):
    cijfers.append(randomgetal)
    print("er is een waarde toegevoegd aan de lijst")
    lengte_lijst = len(cijfers)
    if lengte_lijst > 20:
        cijfers.pop(0)

def output_weergave():
    lengte_lijst = len(cijfers)
    gemiddeld = sum(cijfers) / len(cijfers)
    if lengte_lijst == 20:
        print("het gemiddelde is " + str(round(gemiddeld, 2)))

#MAIN FUNCTION
def main():
    programm_running = True
    while programm_running == True:
        gebruiker_input = input("kies een getal: ")
        if gebruiker_input == "." :
            programm_running = False
        else :
            data_toevoegen(int(gebruiker_input))
            output_weergave()
    print ("einde")

#START PROGRAM
if __name__ == '__main__':
    main()