#!usr/bin/env python

#INFO
__author__ = "Alana Ackermans"
__version__ = "0.0.1"

#LIBRARIES



#FUNCTIONS
#LISTS
tekst = ["happy birthday", "to you", "in de wei staat een koe"]
#CLASSES
class Liedje:
    def __init__(self, tekst):
        self.tekst = tekst

    def zingen(self):
        for regel in self.tekst:
            print(regel)

#MAIN FUNCTION
def main():
    verjaardagslied = Liedje(tekst)
    verjaardagslied.zingen()

#START PROGRAM
if __name__ == '__main__':
    main()